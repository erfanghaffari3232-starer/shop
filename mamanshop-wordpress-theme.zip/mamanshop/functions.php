<?php
if (!defined('ABSPATH')) exit;
function mamanshop_setup(){
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('woocommerce');
  add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
  register_nav_menus(array('primary'=>__('منوی اصلی','mamanshop')));
}
add_action('after_setup_theme','mamanshop_setup');
function mamanshop_assets(){wp_enqueue_style('mamanshop-style',get_stylesheet_uri(),array(), '1.0.0');}
add_action('wp_enqueue_scripts','mamanshop_assets');
