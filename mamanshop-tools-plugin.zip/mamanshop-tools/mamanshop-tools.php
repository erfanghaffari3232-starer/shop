<?php
/**
 * Plugin Name: MamaShop Tools
 * Description: امکانات پایه اختصاصی مامان‌شاپ برای فروشگاه ووکامرس.
 * Version: 1.0.0
 * Author: MamaShop
 * Text Domain: mamanshop-tools
 */
if (!defined('ABSPATH')) exit;
add_action('before_woocommerce_init', function(){ if(class_exists('Automattic\\WooCommerce\\Utilities\\FeaturesUtil')) { Automattic\\WooCommerce\\Utilities\\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true); } });
add_action('admin_notices', function(){
 if (!current_user_can('manage_woocommerce')) return;
 if (!class_exists('WooCommerce')) echo '<div class="notice notice-warning"><p>برای استفاده از امکانات مامان‌شاپ، ابتدا WooCommerce را نصب و فعال کنید.</p></div>';
});
add_action('woocommerce_product_options_pricing', function(){
 woocommerce_wp_text_input(array('id'=>'_mamanshop_badge','label'=>'برچسب فروشگاه','desc_tip'=>true,'description'=>'مثلاً پیشنهاد ویژه یا جدید'));
});
add_action('woocommerce_admin_process_product_object', function($product){
 if(isset($_POST['_mamanshop_badge'])) $product->update_meta_data('_mamanshop_badge', sanitize_text_field(wp_unslash($_POST['_mamanshop_badge'])));
});
add_action('woocommerce_single_product_summary', function(){
 global $product;
 if(!$product) return;
 $badge=$product->get_meta('_mamanshop_badge');
 if($badge) echo '<p style="display:inline-block;background:#fff0f7;color:#542080;padding:5px 12px;border-radius:20px;font-weight:bold">'.esc_html($badge).'</p>';
}, 7);
